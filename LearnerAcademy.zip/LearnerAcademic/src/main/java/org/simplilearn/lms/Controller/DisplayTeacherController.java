package org.simplilearn.lms.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.simplilearn.lms.entities.Subject;
import org.simplilearn.lms.entities.Teacher;
import org.simplilearn.lms.service.SubjectServices;
import org.simplilearn.lms.service.SubjectServicesImpl;
import org.simplilearn.lms.service.TeacherService;
import org.simplilearn.lms.service.TeacherServiceImpl;
@WebServlet("/DisplayTeacher")
public class DisplayTeacherController extends HttpServlet {
	private TeacherService service=new TeacherServiceImpl();
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		List<Teacher> teachers=service.getTeachers();
		req.setAttribute("teachers",teachers);
		RequestDispatcher rd=req.getRequestDispatcher("DisplayTeacher.jsp");
		rd.forward(req, resp);
	}

}
