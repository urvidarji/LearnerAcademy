package org.simplilearn.lms.service;

import java.util.List;

import org.simplilearn.lms.entities.Subject;
import org.simplilearn.lms.entities.Teacher;

public interface SubjectServices {
	void addSubject(Subject subject);
	void deleteSubject(Subject subject);
	void update(Subject subject);
	List<Subject> getSubjects();
	Teacher getTeacher(String name);
	void getAll(Teacher teacher);
	
	

}
