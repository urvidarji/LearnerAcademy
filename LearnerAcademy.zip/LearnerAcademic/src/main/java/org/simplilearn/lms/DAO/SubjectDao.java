package org.simplilearn.lms.DAO;

import java.util.List;

import org.simplilearn.lms.entities.Subject;
import org.simplilearn.lms.entities.Teacher;

public interface SubjectDao {
	void insert(Subject subject);
	List<Subject> getAll();
	void delete(Subject sid);
	void update(Subject subject);
	Teacher get(String name);
	Subject get(int sid);
	
}
