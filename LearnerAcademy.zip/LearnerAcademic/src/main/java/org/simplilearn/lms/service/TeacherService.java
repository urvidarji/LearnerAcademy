package org.simplilearn.lms.service;

import java.util.List;

import org.simplilearn.lms.entities.Subject;
import org.simplilearn.lms.entities.Teacher;

public interface TeacherService {
	void addTeacher(Teacher teacher);
	void deleteTeacher(Teacher teacher);
	Teacher getTeacher(String name);
	List<Teacher> getTeachers();
}
